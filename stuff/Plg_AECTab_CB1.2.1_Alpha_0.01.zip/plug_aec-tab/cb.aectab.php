<?php
/*************************************************************************************
* AEC Tabs for CB 
* Author: Jason D'Souza
* Date: November 2009
* Version: 1.0 beta
* Released under GNU GPL Public License         http://www.gnu.org/copyleft/gpl.html
*************************************************************************************/


/** ensure this file is being included by a parent file */
if ( ! ( defined( '_VALID_CB' ) || defined( '_JEXEC' ) || defined( '_VALID_MOS' ) ) ) {	die( 'Direct Access to this location is not allowed.' ); }



/*
Subscriptions tab class
*/

class getSubscriptionTab extends cbTabHandler {
	
	function getSubscriptionTab() {
		$this->cbTabHandler();		
	}
	
	function getDisplayTab($tab,$user,$ui) {
		global $_CB_framework, $_CB_database, $mainframe, $_REQUEST, $ueConfig;

		if ( isset( $_REQUEST['user'] ) ) {
			if ( $_REQUEST['user'] != $_CB_framework->myId() ) {
				return;
			}
		}
		
		$params = $this->params;
		
		$return		=	'';
		
		$return .= $this->_writeTabDescription( $tab, $user );
		
		$return .= '<div id="cbSubscriptionTabContent"></div>
<style type="text/css">
div#aec_navlist_profile{display:none}
</style>
<script type="text/javascript">
jQuery.noConflict();
jQuery(document).ready(function(){
	var $responseSub = jQuery.ajax({
		url: "'.JURI::base().'index.php?option=com_acctexp&task=subscriptiondetails&sub=overview" ,
		dataType: "html",
		async: false,
		cache: false,
		success: function(){
		},
		error: function(data){
			jQuery("div#cbSubscriptionTabContent").html("<p>Information Currently Unavailable</p>");
		}
	}).responseText;
	headCode = jQuery($responseSub).find("div#subscription_details div");
	subuser = jQuery("td#cbfv_42").html();
	subplan = jQuery("td#cbfv_104").html();
	currPlan = "<div id=\'currentPlan\'><p><strong>Hi "+subuser+", you are currently subscribed to the <em><strong>"+subplan+"</strong></em> plan.</strong></p></div>";
	jQuery("div#cbSubscriptionTabContent").append(currPlan).append(headCode);
	jQuery("div#aec_navlist_profile").remove();
	jQuery("div#days_left p").prepend("You have ")
});
</script>';
		
		return $return;
		
	}
	
}

/*
Invoices tab class
*/

class getInvoicesTab extends cbTabHandler {
	
	function getInvoicesTab() {
		$this->cbTabHandler;		
	}
	
	function getDisplayTab($tab,$user,$ui) {
		global $_CB_framework, $_CB_database, $mainframe, $_REQUEST, $ueConfig;

		if ( isset( $_REQUEST['user'] ) ) {
			if ( $_REQUEST['user'] != $_CB_framework->myId() ) {
				return;
			}
		}
		
		$params = $this->params;

		$return		=	'';
		
		$return .= $this->_writeTabDescription( $tab, $user );
		
		$return .= '<div id="cbInvoicesTabContent"></div>
<style type="text/css">

</style>
<script type="text/javascript">
jQuery.noConflict();
jQuery(document).ready(function(){
	var $responseInv = jQuery.ajax({
		url: "'.JURI::base().'index.php?option=com_acctexp&task=subscriptiondetails&sub=invoices" ,
		dataType: "html",
		async: false,
		cache: false,
		success: function(){
		},
		error: function(data){
			jQuery("div#cbInvoicesTabContent").html("<p>Information Currently Unavailable</p>");
		}
	}).responseText
	invCode = jQuery($responseInv).find("div#subscription_details table");	
	jQuery("div#cbInvoicesTabContent").append(invCode);
});
</script>';
		
		return $return;
		
	}
}

/*
Ticket Tab Class
*/

class getTicketsTab extends cbTabHandler {
	
	function getTicketsTab() {
		$this->cbTabHandler();		
	}
	
	function getDisplayTab($tab,$user,$ui) {
		global $_CB_framework, $_CB_database, $mainframe, $_REQUEST, $ueConfig;

		if ( isset( $_REQUEST['user'] ) ) {
			if ( $_REQUEST['user'] != $_CB_framework->myId() ) {
				return;
			}
		}
		
		$params = $this->params;
		
		$return		=	'';
		
		$return .= $this->_writeTabDescription( $tab, $user );
		
		$return .= '<div id="cbTicketTabContent"></div>
<style type="text/css">

</style>
<script type="text/javascript">
jQuery.noConflict();
jQuery(document).ready(function(){
	var $responseTkt = jQuery.ajax({
		url: "'.JURI::base().'index.php?option=com_rstickets&page=my_tickets" ,
		dataType: "html",
		async: false,
		cache: false,
		success: function(){
		},
		error: function(data){
			jQuery("div#cbTicketTabContent").html("<p>Information Currently Unavailable</p>");
		}
	}).responseText
	tktCode = jQuery($responseTkt).find("div#rst_content div");
	jQuery("div#cbTicketTabContent").append(tktCode);
});
</script>';
		
		return $return;
		
	}
	
}

?>